RASPBERRY_PI_USER="sdc"
RASPBERRY_PI_IP="192.168.209.127"
RASPBERRY_PI_PASSWORD="cransdc"
REMOTE_SCRIPT_PATH="/home/sdc/satde/main_test.py"
LOG_FILE="raspi_log.txt"


# Function to execute the remote script and log output
function execute_remote_script() {
    echo "Executing remote script..."
    ssh $RASPBERRY_PI_USER@$RASPBERRY_PI_IP "python3 $REMOTE_SCRIPT_PATH" | tee -a $LOG_FILE
    echo "Remote script execution finished."
}
# Function to update parameters
function update_parameters() {
    local phase_value=$1
    local calibration_type=$2
    local distance_wall=$3
    shift 3
    local lois_values=("$@")
    
    echo "Updating parameters..."
    {
        echo "$phase_value"
        echo "$calibration_type"
        echo "$distance_wall"
        for value in "${lois_values[@]}"; do
            echo "$value"
        done
    } | ssh $RASPBERRY_PI_USER@$RASPBERRY_PI_IP "cat > /tmp/phase_value.txt"
    echo "Parameters updated."
}
# Main loop to listen for commands
while true; do
    read -p "Enter command (run/update/exit): " cmd
    case $cmd in
        run)
            execute_remote_script
            ;;
        update)
            while true; do
                read -p "Enter new phase value (1-3): " phase_value
                if [[ "$phase_value" =~ ^[1-3]$ ]]; then
                    break
                else
                    echo "Invalid phase value. Please enter an integer between 1 and 3."
                fi
            done
            read -p "Enter calibration type (central/corners): " calibration_type
            read -p "Enter distance to wall: " distance_wall
            echo "Enter the LOIS coordinates as pairs (x,y), space-separated (e.g., 1,2 0,2 3,4):"
            read -a lois_values
            update_parameters $phase_value $calibration_type $distance_wall "${lois_values[@]}"
            ;;
        exit)
            break
            ;;
        *)
            echo "Invalid command"
            ;;
    esac
done

