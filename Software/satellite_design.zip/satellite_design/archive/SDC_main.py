import cv2
import numpy as np
import smbus2
import spidev
import RPi.GPIO as GPIO
import time
import socket
import json
import csv

# Setup GPIO mode
GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)

# ANSI escape codes for some colors
RED = '\033[91m'
GREEN = '\033[92m'
YELLOW = '\033[93m'
ENDC = '\033[0m'  # Reset color

# GPIO setup for reaction wheel control (example pins)
REACTION_WHEEL_PIN = 17
GPIO.setup(REACTION_WHEEL_PIN, GPIO.OUT)

# I2C setup for IMU (example address)
I2C_BUS = 1
IMU_ADDRESS = 0x68  # Replace with actual IMU address
i2c = smbus2.SMBus(I2C_BUS)

# SPI setup (if needed for other sensors)
spi = spidev.SpiDev()
spi.open(0, 0)
spi.max_speed_hz = 50000

# WiFi setup for communication with ground station
GROUND_STATION_IP = '192.168.1.100'  # Replace with the ground station's IP address
GROUND_STATION_PORT = 5000
sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

# CSV logging setup
log_file = "/home/pi/data_log.csv"  # Replace with the actual path to the SD card

# Function to read IMU data (example for MPU6050)
def read_imu():
    # Read the accelerometer and gyroscope data from the IMU
    # This is just an example, adjust according to your IMU's datasheet
    accel_x = i2c.read_byte_data(IMU_ADDRESS, 0x3B)
    accel_y = i2c.read_byte_data(IMU_ADDRESS, 0x3D)
    accel_z = i2c.read_byte_data(IMU_ADDRESS, 0x3F)
    gyro_x = i2c.read_byte_data(IMU_ADDRESS, 0x43)
    gyro_y = i2c.read_byte_data(IMU_ADDRESS, 0x45)
    gyro_z = i2c.read_byte_data(IMU_ADDRESS, 0x47)
    return (accel_x, accel_y, accel_z), (gyro_x, gyro_y, gyro_z)

# Function to control reaction wheel
def control_reaction_wheel(torque):
    if torque > 0:
        GPIO.output(REACTION_WHEEL_PIN, GPIO.HIGH)
    else:
        GPIO.output(REACTION_WHEEL_PIN, GPIO.LOW)

# Function to calculate centroid of a contour
def get_centroid(contour):
    moment = cv2.moments(contour)
    cx = int(moment['m10'] / moment['m00'])
    cy = int(moment['m01'] / moment['m00'])
    return (cx, cy)

# Function to interpolate points between two centroids
def interpolate(start, end, num_points):
    return np.round(np.linspace(start, end, num=num_points)).astype(int)

# Function to find grid in the image
def find_grid(image):
    edges = cv2.Canny(image, 100, 150, apertureSize=3)
    contours, _ = cv2.findContours(edges.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    contours = sorted(contours, key=cv2.contourArea, reverse=True)[:4]
    centroids = [get_centroid(contour) for contour in contours]
    centroids = np.array(centroids)
    centroids_sorted_by_y = centroids[np.argsort(centroids[:, 1])]
    top_half = centroids_sorted_by_y[:2]
    bottom_half = centroids_sorted_by_y[2:]
    top_sorted_by_x = top_half[np.argsort(top_half[:, 0])]
    bottom_sorted_by_x = bottom_half[np.argsort(bottom_half[:, 0])]
    sorted_centroids = np.vstack([top_sorted_by_x, bottom_sorted_by_x])
    top_left, top_right, bottom_left, bottom_right = sorted_centroids
    num_points = 5
    top_edge = interpolate(top_left, top_right, num_points)
    bottom_edge = interpolate(bottom_left, bottom_right, num_points)
    left_edge = interpolate(top_left, bottom_left, num_points)
    right_edge = interpolate(top_right, bottom_right, num_points)
    grid_points = np.array([interpolate(left_edge[i], right_edge[i], num_points) for i in range(num_points)]).reshape(-1, 2)
    return grid_points

# Function to read centroid intensity
def read_centroid_intensity(image, grid_points, area_size=5, area_mode=False):
    intensities = []
    if not area_mode:
        for x, y in grid_points:
            if x >= 0 and y >= 0 and y < image.shape[0] and x < image.shape[1]:
                intensity = image[y, x]
                intensities.append(intensity)
            else:
                intensities.append(None)
    else:
        offset = area_size // 2
        for x, y in grid_points:
            x_start = max(x - offset, 0)
            y_start = max(y - offset, 0)
            x_end = min(x + offset + 1, image.shape[1])
            y_end = min(y + offset + 1, image.shape[0])
            centroid_area = image[y_start:y_end, x_start:x_end]
            if centroid_area.size > 0:
                average_intensity = np.mean(centroid_area)
                intensities.append(average_intensity)
            else:
                intensities.append(None)
    return intensities

# Function to classify grid based on intensity
def classify_grid(intensities):
    intensities = np.array(intensities)
    classifications = np.empty((5, 5), dtype='U4')
    for i in range(5):
        for j in range(5):
            if intensities[i][j] >= 50:
                classifications[i][j] = 'fire'
            elif np.any(intensities[max(0, i-1):min(5, i+2), max(0, j-1):min(5, j+2)] >= 50):
                classifications[i][j] = 'evac'
            else:
                classifications[i][j] = 'safe'
    return classifications

# PID control variables
integral_error = [0, 0, 0]
previous_error = [0, 0, 0]

def apply_orientation_correction(current_orientation, target_orientation):
    global integral_error, previous_error
    Kp = 1
    Ki = 0.005
    Kd = 0.3
    dt = 1. / 240.
    diff_euler = np.subtract(current_orientation, target_orientation)
    integral_error = [ie + de * dt for ie, de in zip(integral_error, diff_euler)]
    derivative_error = [(de - pe) / dt for de, pe in zip(diff_euler, previous_error)]
    previous_error = diff_euler
    torque = [Kp * e + Ki * ie + Kd * de for e, ie, de in zip(diff_euler, integral_error, derivative_error)]
    control_reaction_wheel(torque[2])
    return torque

def log_data_to_sd(data):
    with open(log_file, mode='a') as file:
        writer = csv.writer(file)
        writer.writerow(data)

def send_data_to_ground_station(data):
    sock.sendto(data.encode(), (GROUND_STATION_IP, GROUND_STATION_PORT))

# Main loop for processing images and controlling orientation
def main():
    cap = cv2.VideoCapture(0)  # Assuming the IR camera is connected and accessible
    if not cap.isOpened():
        print("Error: Could not open camera.")
        return

    # Capture initial orientation at startup
    _, initial_orientation = read_imu()
    target_orientation = initial_orientation

    while True:
        ret, frame = cap.read()
        if not ret:
            print("Error: Could not read frame.")
            break

        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        grid_points = find_grid(gray)
        centroid_intensities = read_centroid_intensity(gray, grid_points, area_mode=True)
        grid_intensities = [centroid_intensities[i:i + 5] for i in range(0, len(centroid_intensities), 5)]
        classifications = classify_grid(grid_intensities)

        for row in classifications:
            for elem in row:
                print(f"{get_color(elem)}{elem}{ENDC}", end=' ')
            print()

        # Read current orientation from IMU
        _, current_orientation = read_imu()
        # Apply orientation correction and get torque
        torque = apply_orientation_correction(current_orientation, target_orientation)

        # Prepare data for ground station
        data = {
            'grid_intensities': grid_intensities.tolist(),
            'classifications': classifications.tolist(),
            'current_orientation': current_orientation,
            'torque': torque
        }
        data_json = json.dumps(data)
        
        # Log data to SD card
        log_data_to_sd([time.time(), grid_intensities, classifications, current_orientation, torque])

        # Send data to ground station
        send_data_to_ground_station(data_json)
        time.sleep(1. / 240.)

    cap.release()
    cv2.destroyAllWindows()

if __name__ == "__main__":
    main()

    # Cleanup GPIO
    GPIO.cleanup()
    spi.close()
    sock.close()
