import socket
import json
import csv
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation

# Setup UDP server
LOCAL_IP = '0.0.0.0'  # Listen on all interfaces
LOCAL_PORT = 5000
sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
sock.bind((LOCAL_IP, LOCAL_PORT))

log_file = "ground_station_log.csv"

# Setup for live plotting
fig, (ax1, ax2) = plt.subplots(2, 1)
grid_image = np.zeros((5, 5))
orientation_data = []
torque_data = []

def update_plot(frame):
    ax1.clear()
    ax1.imshow(grid_image, cmap='hot', interpolation='nearest')
    ax1.set_title("Grid Intensities")

    ax2.clear()
    ax2.plot(orientation_data, label='Orientation')
    ax2.plot(torque_data, label='Torque')
    ax2.legend()
    ax2.set_title("Orientation and Torque")
    ax2.set_xlabel("Time")
    ax2.set_ylabel("Values")

def log_data_to_csv(data):
    with open(log_file, mode='a') as file:
        writer = csv.writer(file)
        writer.writerow(data)

def main():
    ani = FuncAnimation(fig, update_plot, interval=1000)
    plt.ion()
    plt.show()

    while True:
        data, addr = sock.recvfrom(1024)  # Buffer size is 1024 bytes
        data = data.decode()
        data_dict = json.loads(data)

        print(f"Received data from {addr}: {data_dict}")

        grid_image[:] = data_dict['grid_intensities']
        orientation_data.append(data_dict['current_orientation'])
        torque_data.append(data_dict['torque'])

        log_data_to_csv([time.time(), data_dict['grid_intensities'], data_dict['classifications'], data_dict['current_orientation'], data_dict['torque']])

        plt.draw()
        plt.pause(0.001)

if __name__ == "__main__":
    main()
