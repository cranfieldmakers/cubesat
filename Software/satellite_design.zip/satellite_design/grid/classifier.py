def classify_grid(grid_data, LOIs=None, threshold_high=50):
    def adjacent_to_heat_source(grid_data, i, j, threshold_high):
        directions = [(-1, 0), (1, 0), (0, -1), (0, 1)]
        for di, dj in directions:
            ni, nj = i + di, j + dj
            if 0 <= ni < len(grid_data) and 0 <= nj < len(grid_data[0]):
                if grid_data[ni][nj] > threshold_high:
                    return True
        return False

    classifications = []
    for i, row in enumerate(grid_data):
        row_classifications = []
        for j, temp in enumerate(row):
            if temp > threshold_high:
                classification = 'Location on Fire'
            elif adjacent_to_heat_source(grid_data, i, j, threshold_high):
                classification = 'Evacuate'
            else:
                classification = 'Location is Safe'

            row_classifications.append(classification)
        classifications.append(row_classifications)

    # Modify classifications based on LOIs if provided
    if LOIs:
        for i, j in LOIs:
            if 0 <= i < len(grid_data) and 0 <= j < len(grid_data[0]):
                if grid_data[i][j] > threshold_high:
                    classifications[i][j] = 'Location on Fire'
                elif adjacent_to_heat_source(grid_data, i, j, threshold_high):
                    classifications[i][j] = 'Evacuate'
                else:
                    classifications[i][j] = 'Location is Safe'

    return classifications

def adjacent_to_heat_source(grid_data, x, y, threshold_high):
    for dx in [-1, 0, 1]:
        for dy in [-1, 0, 1]:
            if 0 <= x+dx < len(grid_data) and 0 <= y+dy < len(grid_data[0]):
                if grid_data[x+dx][y+dy] > threshold_high:
                    return True
    return False
