import numpy as np
import matplotlib.pyplot as plt
import random

# Threshold for detecting the heat source
threshold_high = 50

class Calibration:
    def __init__(self, threshold=threshold_high):
        self.threshold_high = threshold

    def create_test_image(self, size, heat_source_positions, heat_intensity=100):
        image = np.zeros((size, size))
        for pos in heat_source_positions:
            image[pos] = heat_intensity
        return image

    def detect_corners(self, ir_readings):
        heat_sources = np.argwhere(ir_readings > self.threshold_high)
        if len(heat_sources) < 4:
            return None
        top_left = heat_sources[np.argmin(np.sum(heat_sources, axis=1))]
        bottom_right = heat_sources[np.argmax(np.sum(heat_sources, axis=1))]
        top_right = heat_sources[np.argmax(np.diff(heat_sources, axis=1))]
        bottom_left = heat_sources[np.argmin(np.diff(heat_sources, axis=1))]
        return [top_left, top_right, bottom_left, bottom_right]

    def get_heat_source_position(self, ir_readings):
        max_temp = self.threshold_high
        position = None
        for i, row in enumerate(ir_readings):
            for j, temp in enumerate(row):
                if temp > max_temp:
                    max_temp = temp
                    position = (i, j)
        return position

    def calculate_midpoints(self, p1, p2, num_points):
        return [(p1[0] + i * (p2[0] - p1[0]) / (num_points - 1),
                 p1[1] + i * (p2[1] - p1[1]) / (num_points - 1)) for i in range(num_points)]

    def create_grid(self, corners, grid_size=5):
        top_left, top_right, bottom_left, bottom_right = corners

        left_midpoints = self.calculate_midpoints(top_left, bottom_left, grid_size)
        right_midpoints = self.calculate_midpoints(top_right, bottom_right, grid_size)

        grid_positions = []
        for i in range(grid_size):
            grid_positions.append(self.calculate_midpoints(left_midpoints[i], right_midpoints[i], grid_size))

        return grid_positions

    def create_central_grid(self, center_position, grid_size=5):
        half_grid_size = grid_size // 2
        center_x, center_y = center_position
        grid_positions = []

        for i in range(-half_grid_size, half_grid_size + 1):
            row = []
            for j in range(-half_grid_size, half_grid_size + 1):
                x = center_x + i
                y = center_y + j
                row.append((x, y))
            grid_positions.append(row)

        return grid_positions

    def central_calibration(self, ir_readings):
        heat_source_position = self.get_heat_source_position(ir_readings)

        if heat_source_position is None:
            print("No heat source detected for central calibration.")
            return None

        return self.create_central_grid(heat_source_position)

    def corners_calibration(self, ir_readings):
        corners = self.detect_corners(ir_readings)

        if len(corners) != 4:
            print("Insufficient corners detected for corners calibration.")
            return None

        return self.create_grid(corners)

    def overlay_grid(self, image, positions):
        grid_overlay = np.copy(image)

        for row in positions:
            for (x, y) in row:
                if 0 <= int(x) < image.shape[0] and 0 <= int(y) < image.shape[1]:
                    grid_overlay[int(x), int(y)] = 255  # Mark the grid cells with a distinct value

        return grid_overlay

    def plot_with_grid(self, ax, image, positions):
        ax.imshow(image, cmap='hot', interpolation='nearest')

        for row in positions:
            for (x, y) in row:
                if 0 <= int(x) < image.shape[0] and 0 <= int(y) < image.shape[1]:
                    ax.plot(int(y), int(x), 'go')  # Mark the grid points

        for i in range(len(positions)):
            if 0 <= int(positions[i][0][0]) < image.shape[0]:
                ax.axhline(int(positions[i][0][0]) - 0.5, color='green', linestyle='--', linewidth=0.5)
            if 0 <= int(positions[0][i][1]) < image.shape[1]:
                ax.axvline(int(positions[0][i][1]) - 0.5, color='green', linestyle='--', linewidth=0.5)

    def read_grid_temperatures(self, image, positions):
        grid_temperatures = []

        for row in positions:
            temp_row = []
            for (x, y) in row:
                if 0 <= int(x) < image.shape[0] and 0 <= int(y) < image.shape[1]:
                    temp_row.append(image[int(x), int(y)])
                else:
                    temp_row.append(None)
            grid_temperatures.append(temp_row)

        return grid_temperatures

    def run_test(self, calibration_type='central'):
        size = 15
        square_size = 5  # Define the size of the square
        if calibration_type == 'central':
            heat_source_positions = [(7, 8)]  # Slightly off-center
        elif calibration_type == 'corners':
            top_left_x = random.randint(0, size - square_size)
            top_left_y = random.randint(0, size - square_size)
            heat_source_positions = [
                (top_left_x, top_left_y),
                (top_left_x, top_left_y + square_size - 1),
                (top_left_x + square_size - 1, top_left_y),
                (top_left_x + square_size - 1, top_left_y + square_size - 1)
            ]

        image = self.create_test_image(size, heat_source_positions)

        if calibration_type == 'central':
            positions = self.central_calibration(image)
        elif calibration_type == 'corners':
            positions = self.corners_calibration(image)

        if positions is None:
            print("Calibration failed.")
            return

        # Overlay the grid on the image
        grid_image = self.overlay_grid(image, positions)

        # Read the grid temperatures
        grid_temperatures = self.read_grid_temperatures(image, positions)
        print("Grid Temperatures:")
        for row in grid_temperatures:
            print(row)

        # Visualize the original image and the image with the grid overlay
        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(10, 5))
        ax1.imshow(image, cmap='hot', interpolation='nearest')
        ax1.set_title('Original Image')

        self.plot_with_grid(ax2, grid_image, positions)
        ax2.set_title('Image with Grid Overlay')

        plt.show()


if __name__ == '__main__':
    calibration = Calibration()
    calibration.run_test(calibration_type='central')  # Change this to 'central' to test central calibration
