import smbus2
import threading
import time

from components.imu import IMU
from components.light_sensor import LightSensor
from components.ir_camera import IR_Camera
from components.motor_driver import MotorDriver
from components.power_subsystem import PowerSubsystem
from components.pid_controller import PIDController
from comms.ssh_connection import SSHConnection
from grid.classifier import classify_grid
from grid.calibration import Calibration

#Light sensor threshold
threshold_light = 50

#Heat sensor threshold
threshold_high = 50

#Message ID for sent messages
SEND_TYPE = 3

# Initialize components
imu = IMU()
light_sensors = [LightSensor(port) for port in [1, 2]]
ir_camera = IR_Camera()
motor_driver = MotorDriver()
power_subsystem = PowerSubsystem()
calibration = Calibration(threshold_high)

# PID Controllers for Roll, Pitch, and Yaw
pid_roll = PIDController(Kp=1.0, Ki=0.1, Kd=0.05, integral_limit=100)
pid_pitch = PIDController(Kp=1.0, Ki=0.1, Kd=0.05, integral_limit=100)
pid_yaw = PIDController(Kp=1.0, Ki=0.1, Kd=0.05, integral_limit=100)

# Establish SSH communication
ssh_conn = SSHConnection('ground_station_ip', 'username', 'password')

# Global variable to store current phase and grid calibration
current_phase = 1
grid_calibration = None
phase_lock = threading.Lock()

def health_check():
    position = imu.get_position()
    rotation = imu.get_rotation()
    power_state = power_subsystem.get_state()
    axial_velocities = imu.get_axial_velocities()
    light_readings = [sensor.get_reading() for sensor in light_sensors]
    ir_readings = ir_camera.get_readings()
    grid_position = perform_calibration()

    # Read the grid temperatures
    grid_temperatures = calibration.read_grid_temperatures(ir_readings, grid_position)

    telemetry_data = {
        'position': position,
        'rotation': rotation,
        'power_state': power_state,
        'axial_velocities': axial_velocities,
        'light_readings': light_readings,
        'ir_readings': ir_readings,
        'grid_position': grid_position,
        'grid_temperatures': grid_temperatures,
    }
    ssh_conn.send(telemetry_data,1)


def perform_calibration():
    global grid_calibration
    ssh_conn.send({'status': 'Enter Calibration type', 'calibration': grid_calibration},SEND_TYPE)

    calibration_type = ssh_conn.receive()

    if calibration_type == 'Central':
        print("Performing central heatlamp calibration...")
        grid_calibration = calibration.central_calibration(ir_camera.get_readings())
    elif calibration_type == 'Corners':
        print("Performing four corners calibration...")
        grid_calibration = calibration.corners_calibration(ir_camera.get_readings())

    ssh_conn.send({'status': 'Calibration complete', 'calibration': grid_calibration},SEND_TYPE)
    return grid_calibration


def stabilize_position():
    rotation = imu.get_rotation()

    roll_output = pid_roll.update(rotation['roll'])
    pitch_output = pid_pitch.update(rotation['pitch'])
    yaw_output = pid_yaw.update(rotation['yaw'])

    # Example control logic for motor based on PID output
    motor_speed = max(min(abs(roll_output), 100), 0)
    motor_driver.set_motor_speed(motor_speed)

    if roll_output > 0:
        motor_driver.set_motor_direction(forward=True)
    else:
        motor_driver.set_motor_direction(forward=False)


def search_heat_source():
    motor_driver.set_motor_direction(forward=True)
    motor_driver.set_motor_speed(50)

    while not is_sun_at_edge():
        time.sleep(0.1)
        if heat_source_detected(ir_camera.get_readings()):
            motor_driver.stop_motor()
            return True

    motor_driver.set_motor_direction(forward=False)

    while not is_sun_at_other_edge():
        time.sleep(0.1)
        if heat_source_detected(ir_camera.get_readings()):
            motor_driver.stop_motor()
            return True

    motor_driver.stop_motor()
    return False


def is_sun_at_edge():
    light_readings = [sensor.get_reading() for sensor in light_sensors]
    # Define your condition for detecting the sun at the edge
    return light_readings[0] > threshold_light and light_readings[1] < threshold_light


def is_sun_at_other_edge():
    light_readings = [sensor.get_reading() for sensor in light_sensors]
    # Define your condition for detecting the sun at the other edge
    return light_readings[0] < threshold_light and light_readings[1] > threshold_light


def heat_source_detected(ir_readings):
    for row in ir_readings:
        for temp in row:
            if temp > threshold_high:  # Assume some threshold for detecting the heat source
                return True
    return False


def center_heat_source():
    while True:
        ir_readings = ir_camera.get_readings()
        heat_source_position = calibration.get_heat_source_position(ir_readings)
        if heat_source_position is None:
            break  # Heat source lost

        # Assuming the IR camera has a 5x5 grid
        center_x, center_y = 2, 2
        delta_x = heat_source_position[0] - center_x
        delta_y = heat_source_position[1] - center_y

        if delta_x == 0 and delta_y == 0:
            break  # Heat source centered

        # Adjust orientation to center the heat source
        if delta_x != 0:
            motor_driver.set_motor_direction(forward=(delta_x > 0))
            motor_driver.set_motor_speed(50)
            time.sleep(0.1)
            motor_driver.stop_motor()
        if delta_y != 0:
            motor_driver.set_motor_direction(forward=(delta_y > 0))
            motor_driver.set_motor_speed(50)
            time.sleep(0.1)
            motor_driver.stop_motor()


def command_listener():
    global current_phase
    while True:
        command = ssh_conn.receive()
        with phase_lock:
            if command == 'SWITCH_TO_PHASE_1':
                current_phase = 1
            elif command == 'SWITCH_TO_PHASE_2':
                current_phase = 2
            elif command == 'SWITCH_TO_PHASE_3':
                current_phase = 3
            elif command == 'LOIS':

                LOIs = None
        time.sleep(1)


def main():
    listener_thread = threading.Thread(target=command_listener)
    listener_thread.daemon = True
    listener_thread.start()

    try:
        while True:
            with phase_lock:
                phase = current_phase

            if phase == 1:
                health_check()

            elif phase == 2:

                if LOIs is None:

                    ssh_conn.send("Send",SEND_TYPE)
                    LOIs = ssh_conn.receive_LOIs()


                ir_readings = ir_camera.get_readings()
                grid_position = perform_calibration()

                # Read the grid temperatures
                grid_temperatures = calibration.read_grid_temperatures(ir_readings, grid_position)
                if LOIs:
                    classifications = classify_grid(grid_temperatures, LOIs)

                result_data = {
                    'classifications': classifications,
                    'ir_readings': grid_temperatures,
                    'telemetry': {
                        'position': imu.get_position(),
                        'rotation': imu.get_rotation(),
                        'power_state': power_subsystem.get_state(),
                        'axial_velocities': imu.get_axial_velocities()
                    }
                }
                ssh_conn.send(result_data,2)

                while True:
                    stabilize_position()
                    time.sleep(0.1)
                    with phase_lock:
                        if current_phase != 2:
                            break
            elif phase == 3:
                while True:
                    stabilize_position()
                    light_readings = [sensor.get_reading() for sensor in light_sensors]
                    if all(light > threshold_light for light in light_readings):
                        break
                    time.sleep(0.1)

                found = search_heat_source()
                if found:
                    center_heat_source()
                    ssh_conn.send({'status': 'Heat source found and centered'})
                else:
                    ssh_conn.send({'status': 'Heat source not found'})

                while True:
                    time.sleep(0.1)
                    with phase_lock:
                        if current_phase != 3:
                            break
            time.sleep(1)
    finally:
        motor_driver.cleanup()


if __name__ == '__main__':
    main()