import paramiko
import struct
import time
import datetime

START_BYTE = 0x02
END_BYTE = 0x03

# Message type identifiers
MESSAGE_TYPE_HEALTH_CHECK = 1
MESSAGE_TYPE_CLASSIFICATION = 2

class SSHConnection:
    def __init__(self, host, username, password):
        self.client = paramiko.SSHClient()
        self.client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        self.client.connect(host, username=username, password=password)
        self.channel = self.client.get_transport().open_session()
        self.channel.get_pty()
        self.channel.invoke_shell()

        self.received_packets = {}
        self.complete_messages = {}


    def crc8(self,data):
        crc = 0
        for byte in data:
            crc ^= byte
            for _ in range(8):
                if crc & 0x80:
                    crc = (crc << 1) ^ 0x07
                else:
                    crc <<= 1
            crc &= 0xFF
        return crc

    def create_packets(self,data, message_type, payload_size):
        packets = []
        idx = 0  # Initialize packet index
        send_byte = START_BYTE
        end_byte = END_BYTE

        data_bytes = str(data).encode('utf-8')
        total_packets = (len(data_bytes) + payload_size - 1) // payload_size

        for i in range(0, len(data_bytes), payload_size):
            # Extract the part of the data for this packet
            packet_data = data_bytes[i:i + payload_size]

            # Compute CRC for the serialized line
            crc = self.crc8(packet_data)

            # Create a timestamp (Unix time in seconds)
            timestamp = int(time.time())

            # Packet structure: [Send Byte, Message Type, Packet Index, Final Packet Index, Timestamp, Data Length, Data, CRC, End Byte]
            packet = struct.pack(f'!BBBBIB{len(packet_data)}sBB',
                                 send_byte, message_type, idx, total_packets - 1, timestamp, len(packet_data),
                                 packet_data, crc, end_byte)

            packets.append(packet)

            # Increment the packet index for the next packet
            idx = (idx + 1) % 256  # Keep it within 1 byte

        return packets


    def unpack_packet(self, packet):
        header_format = '!BBBBIB'
        header_size = struct.calcsize(header_format)

        start, message_type, idx, final_idx, timestamp, data_length = struct.unpack(header_format, packet[:header_size])

        # Unpack the complete message
        data_format = f'!{data_length}sBB'
        data, crc, end = struct.unpack(data_format, packet[header_size:])

        if start != START_BYTE or end != END_BYTE:
            raise ValueError("Invalid start or end byte")

        expected_crc = self.crc8(data)
        if crc != expected_crc:
            raise ValueError("Invalid CRC")

        return message_type, idx, final_idx, timestamp, data.decode('utf-8')


    def translate_packet_info(self, packet):
        header_format = '!BBBBIB'
        header_size = struct.calcsize(header_format)

        start, message_type, idx, final_idx, timestamp, data_length = struct.unpack(header_format, packet[:header_size])

        # Convert the timestamp to a readable format (assuming it's a Unix timestamp)
        readable_timestamp = datetime.datetime.utcfromtimestamp(timestamp).strftime('%Y-%m-%d %H:%M:%S')

        return {"Message Type": message_type, "Packet Index": idx, "Final Packet Index": final_idx, "Timestamp": readable_timestamp}

    def save_to_file(self, message_type, timestamp, data):
        filename = f"Message_log_type_{message_type}.txt"
        with open(filename, 'a') as file:  # Open the file in append mode
            file.write(f"[Timestamp: {timestamp}]")
            file.write(f"[Message Type: {message_type}]")
            file.write(f"[Data: {data}]")
            file.write("\n")  # Add a newline for readability

    def send(self, data, message_type, payload_size=250):
        packets = self.create_packets(data, message_type, payload_size)
        for packet in packets:
            self.channel.sendall(packet)

    def receive(self):
        while True:
            packet = self._receive_packet()
            if packet:
                unpacked_message_type, idx, final_idx, timestamp, unpacked_data = self.unpack_packet(packet)

                # Initialize the storage for received packets if necessary
                if unpacked_message_type not in self.received_packets:
                    self.received_packets[unpacked_message_type] = {}

                # Store the packet data
                self.received_packets[unpacked_message_type][idx] = unpacked_data

                # Check if we have received all packets for this message type
                if len(self.received_packets[unpacked_message_type]) - 1 == final_idx:
                    # Reassemble the complete message
                    complete_data = bytearray()
                    for i in range(final_idx + 1):
                        complete_data.extend(self.received_packets[unpacked_message_type][i].encode('utf-8'))

                    self.complete_messages[unpacked_message_type] = (timestamp, complete_data.decode('utf-8'))

                    # Save the final data to a file
                    readable_timestamp = datetime.datetime.utcfromtimestamp(timestamp).strftime('%Y-%m-%d %H:%M:%S')
                    self.save_to_file(unpacked_message_type, readable_timestamp, complete_data.decode('utf-8'))
                    print(f"Data saved to file for message type {unpacked_message_type}.")
                    return self.complete_messages[unpacked_message_type]

    def _receive_packet(self):
        packet = b''
        while not packet.endswith(struct.pack('B', END_BYTE)):
            packet += self.channel.recv(1)
        return packet

    def close(self):
        self.client.close()

if __name__ == "__main__":
    # Example usage
    ssh_conn = SSHConnection('ground_station_ip', 'username', 'password')
    ssh_conn.send("Hello, Satellite!")
    print(ssh_conn.receive())
    ssh_conn.close()