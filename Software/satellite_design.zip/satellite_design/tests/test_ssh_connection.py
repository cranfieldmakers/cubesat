import struct
import time
import datetime

START_BYTE = 0x02
END_BYTE = 0x03

# Message type identifiers
MESSAGE_TYPE_HEALTH_CHECK = 1
MESSAGE_TYPE_CLASSIFICATION = 2

def crc8(data):
    crc = 0
    for byte in data:
        crc ^= byte
        for _ in range(8):
            if crc & 0x80:
                crc = (crc << 1) ^ 0x07
            else:
                crc <<= 1
        crc &= 0xFF
    return crc

def create_synthetic_health_check():
    synthetic_data = {
        'position': (1.0, 2.0, 3.0),
        'rotation': (0.1, 0.2, 0.3),
        'power_state': 'ON',
        'axial_velocities': (0.01, 0.02, 0.03),
        'light_readings': [10, 20],
        'ir_readings': [
            [30, 40, 50],
            [60, 70, 80],
            [90, 100, 110]
        ]
    }
    return synthetic_data

def create_synthetic_class_check():
    synthetic_data = {
        'position': (1.0, 2.0, 3.0),
        'rotation': (0.1, 0.2, 0.3),
        'power_state': 'ON',
        'axial_velocities': (0.01, 0.02, 0.03),
        'light_readings': [10, 20],
        'ir_readings': [
            [30, 40, 50],
            [60, 70, 80],
            [90, 100, 110]
        ],
        'classifications': [
            [1, 0, 2],
            [0, 2, 2],
            [1, 0, 1],
        ]
    }
    return synthetic_data


def create_packets(data, message_type, payload_size):
    packets = []
    idx = 0  # Initialize packet index
    send_byte = START_BYTE
    end_byte = END_BYTE

    data_bytes = str(data).encode('utf-8')
    total_packets = (len(data_bytes) + payload_size - 1) // payload_size

    for i in range(0, len(data_bytes), payload_size):
        # Extract the part of the data for this packet
        packet_data = data_bytes[i:i + payload_size]

        # Compute CRC for the serialized line
        crc = crc8(packet_data)

        # Create a timestamp (Unix time in seconds)
        timestamp = int(time.time())

        # Packet structure: [Send Byte, Message Type, Packet Index, Final Packet Index, Timestamp, Data Length, Data, CRC, End Byte]
        packet = struct.pack(f'!BBBBIB{len(packet_data)}sBB',
                             send_byte, message_type, idx, total_packets - 1, timestamp, len(packet_data), packet_data, crc, end_byte)

        packets.append(packet)

        # Increment the packet index for the next packet
        idx = (idx + 1) % 256  # Keep it within 1 byte

    return packets


def unpack_packet(packet):
    header_format = '!BBBBIB'
    header_size = struct.calcsize(header_format)

    start, message_type, idx, final_idx, timestamp, data_length = struct.unpack(header_format, packet[:header_size])

    # Unpack the complete message
    data_format = f'!{data_length}sBB'
    data, crc, end = struct.unpack(data_format, packet[header_size:])

    if start != START_BYTE or end != END_BYTE:
        raise ValueError("Invalid start or end byte")

    expected_crc = crc8(data)
    if crc != expected_crc:
        raise ValueError("Invalid CRC")

    return message_type, idx, final_idx, timestamp, data.decode('utf-8')

def translate_packet_info(packet):
    header_format = '!BBBBIB'
    header_size = struct.calcsize(header_format)

    start, message_type, idx, final_idx, timestamp, data_length = struct.unpack(header_format, packet[:header_size])

    # Convert the timestamp to a readable format (assuming it's a Unix timestamp)
    readable_timestamp = datetime.datetime.utcfromtimestamp(timestamp).strftime('%Y-%m-%d %H:%M:%S')

    return {"Message Type": message_type, "Packet Index": idx, "Final Packet Index": final_idx, "Timestamp": readable_timestamp}


def save_to_file(message_type, timestamp, data):
    filename = f"Message_log_type_{message_type}.txt"
    with open(filename, 'a') as file:  # Open the file in append mode
        file.write(f"[Timestamp: {timestamp}],")
        file.write(f"[Message Type: {message_type}],")
        file.write(f"[Data: {data}]")
        file.write("\n")  # Add a newline for readability


def test_message_protocol():
    # Create synthetic health check data
    check_data = create_synthetic_health_check()
    # Create packets for health check data
    payload_size = 250  # Example payload size
    packets = create_packets(check_data, MESSAGE_TYPE_HEALTH_CHECK, payload_size)

    check_data = create_synthetic_class_check()

    # Create packets for classification data
    payload_size = 25  # Example payload size
    packets = create_packets(check_data, MESSAGE_TYPE_CLASSIFICATION, payload_size)

    received_packets = {}
    complete_messages = {}

    # Simulate sending and receiving the packets
    for packet in packets:
        # Unpack the received packet
        unpacked_message_type, idx, final_idx, timestamp, unpacked_data = unpack_packet(packet)

        # Initialize the storage for received packets if necessary
        if unpacked_message_type not in received_packets:
            received_packets[unpacked_message_type] = {}

        # Store the packet data
        received_packets[unpacked_message_type][idx] = unpacked_data

        # Check if we have received all packets for this message type
        if len(received_packets[unpacked_message_type]) - 1 == final_idx:
            # Reassemble the complete message
            complete_data = bytearray()
            for i in range(final_idx + 1):
                complete_data.extend(received_packets[unpacked_message_type][i].encode('utf-8'))

            complete_messages[unpacked_message_type] = (timestamp, complete_data.decode('utf-8'))

            # Translate the packet info
            packet_info = translate_packet_info(packet)
            assert packet_info["Message Type"] == unpacked_message_type, "Message Type mismatch"
            assert packet_info["Packet Index"] == idx, "Packet Index mismatch"
            assert packet_info["Final Packet Index"] == final_idx, "Final Packet Index mismatch"
            assert packet_info["Timestamp"] == datetime.datetime.utcfromtimestamp(timestamp).strftime(
                '%Y-%m-%d %H:%M:%S'), "Timestamp mismatch"

            print("Test passed for packet:", packet)
            print("Packet info:", packet_info)

    # Save the final data to a file for each complete message
    for message_type, (timestamp, data) in complete_messages.items():
        readable_timestamp = datetime.datetime.utcfromtimestamp(timestamp).strftime('%Y-%m-%d %H:%M:%S')
        save_to_file(message_type, readable_timestamp, data)
        print(f"Data saved to file for message type {message_type}.")


if __name__ == "__main__":
    test_message_protocol()