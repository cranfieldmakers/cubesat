import RPi.GPIO as GPIO

# Pin Definitions
IN1 = 17
IN2 = 27
ENA = 18


class MotorDriver:
    def __init__(self):
        GPIO.setmode(GPIO.BCM)
        GPIO.setup(IN1, GPIO.OUT)
        GPIO.setup(IN2, GPIO.OUT)
        GPIO.setup(ENA, GPIO.OUT)

        self.pwm = GPIO.PWM(ENA, 1000)  # 1kHz PWM frequency
        self.pwm.start(0)

    def set_motor_speed(self, speed):
        """
        Sets the motor speed
        :param speed: Speed as a percentage (0 to 100)
        """
        self.pwm.ChangeDutyCycle(speed)

    def set_motor_direction(self, forward=True):
        """
        Sets the motor direction
        :param forward: True for forward, False for backward
        """
        if forward:
            GPIO.output(IN1, GPIO.HIGH)
            GPIO.output(IN2, GPIO.LOW)
        else:
            GPIO.output(IN1, GPIO.LOW)
            GPIO.output(IN2, GPIO.HIGH)

    def stop_motor(self):
        """
        Stops the motor
        """
        GPIO.output(IN1, GPIO.LOW)
        GPIO.output(IN2, GPIO.LOW)
        self.pwm.ChangeDutyCycle(0)

    def cleanup(self):
        """
        Clean up the GPIO pins
        """
        self.pwm.stop()
        GPIO.cleanup()