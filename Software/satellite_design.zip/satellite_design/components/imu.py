import smbus2
import time

# Define I2C bus and address
I2C_BUS = 4
BNO055_ADDRESS = 0x28

# BNO055 Registers
BNO055_CHIP_ID_ADDR = 0x00
BNO055_OPR_MODE_ADDR = 0x3D
BNO055_UNIT_SEL_ADDR = 0x3B
BNO055_PWR_MODE_ADDR = 0x3E
BNO055_SYS_TRIGGER_ADDR = 0x3F
BNO055_TEMP_ADDR = 0x34
BNO055_ACCEL_DATA_X_LSB_ADDR = 0x08
BNO055_EULER_H_LSB_ADDR = 0x1A  # Euler angles start at 0x1A
BNO055_LIN_ACC_DATA_X_LSB_ADDR = 0x28  # Linear acceleration data starts at 0x28

# Operation Modes
OPERATION_MODE_CONFIG = 0x00
OPERATION_MODE_NDOF = 0x0C

class IMU:
    def __init__(self):
        self.bus = smbus2.SMBus(I2C_BUS)
        self.initialize_sensor()

    def read_byte_data(self, register):
        return self.bus.read_byte_data(BNO055_ADDRESS, register)

    def read_i2c_block_data(self, register, length):
        return self.bus.read_i2c_block_data(BNO055_ADDRESS, register, length)

    def write_byte_data(self, register, value):
        self.bus.write_byte_data(BNO055_ADDRESS, register, value)

    def initialize_sensor(self):
        # Check the BNO055 Chip ID
        chip_id = self.read_byte_data(BNO055_CHIP_ID_ADDR)
        if chip_id != 0xA0:
            raise RuntimeError('Failed to find BNO055!')

        # Set to configuration mode
        self.write_byte_data(BNO055_OPR_MODE_ADDR, OPERATION_MODE_CONFIG)
        time.sleep(0.025)

        # Set the power mode to normal
        self.write_byte_data(BNO055_PWR_MODE_ADDR, 0x00)
        time.sleep(0.01)

        # Use external crystal
        self.write_byte_data(BNO055_SYS_TRIGGER_ADDR, 0x80)
        time.sleep(0.01)

        # Set the operation mode to NDOF
        self.write_byte_data(BNO055_OPR_MODE_ADDR, OPERATION_MODE_NDOF)
        time.sleep(0.025)

    def get_position(self):
        x, y, z = self.read_accel_data()
        return {'x': x, 'y': y, 'z': z}

    def get_rotation(self):
        roll, pitch, yaw = self.read_euler_angles()
        return {'roll': roll, 'pitch': pitch, 'yaw': yaw}

    def get_axial_velocities(self):
        x, y, z = self.read_accel_data()
        return {'x_velocity': x, 'y_velocity': y, 'z_velocity': z}

    def read_accel_data(self):
        data = self.read_i2c_block_data(BNO055_ACCEL_DATA_X_LSB_ADDR, 6)

        x = (data[1] << 8) | data[0]
        y = (data[3] << 8) | data[2]
        z = (data[5] << 8) | data[4]

        # Convert to signed 16-bit
        if x > 32767:
            x -= 65536
        if y > 32767:
            y -= 65536
        if z > 32767:
            z -= 65536

        return x, y, z

    def read_euler_angles(self):
        data = self.read_i2c_block_data(BNO055_EULER_H_LSB_ADDR, 6)

        h = (data[1] << 8) | data[0]
        r = (data[3] << 8) | data[2]
        p = (data[5] << 8) | data[4]

        # Convert to signed 16-bit
        if h > 32767:
            h -= 65536
        if r > 32767:
            r -= 65536
        if p > 32767:
            p -= 65536

        # Convert to degrees
        h = h / 16.0
        r = r / 16.0
        p = p / 16.0

        return r, p, h

    def read_linear_acceleration(self):
        data = self.read_i2c_block_data(BNO055_LIN_ACC_DATA_X_LSB_ADDR, 6)

        x = (data[1] << 8) | data[0]
        y = (data[3] << 8) | data[2]
        z = (data[5] << 8) | data[4]

        # Convert to signed 16-bit
        if x > 32767:
            x -= 65536
        if y > 32767:
            y -= 65536
        if z > 32767:
            z -= 65536

        # Convert to m/s^2
        x = x / 100.0
        y = y / 100.0
        z = z / 100.0

        return x, y, z