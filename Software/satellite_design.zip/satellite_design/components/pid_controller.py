import time

class PIDController:
    def __init__(self, Kp, Ki, Kd, setpoint=0, integral_limit=None):
        self.Kp = Kp
        self.Ki = Ki
        self.Kd = Kd
        self.setpoint = setpoint
        self.integral_limit = integral_limit
        self.previous_error = 0
        self.integral = 0
        self.previous_time = time.time()

    def update(self, current_value):
        current_time = time.time()
        dt = current_time - self.previous_time
        if dt == 0:
            dt = 1e-16  # Avoid division by zero

        error = self.setpoint - current_value
        self.integral += error * dt
        if self.integral_limit is not None:
            self.integral = max(min(self.integral, self.integral_limit), -self.integral_limit)
        derivative = (error - self.previous_error) / dt

        output = (self.Kp * error) + (self.Ki * self.integral) + (self.Kd * derivative)

        self.previous_error = error
        self.previous_time = current_time

        return output

    def reset(self):
        self.previous_error = 0
        self.integral = 0
        self.previous_time = time.time()
