import time
import board
import busio
import numpy as np
import adafruit_mlx90640

class IR_Camera:
    def __init__(self):
        # Initialize IR camera
        self.i2c = busio.I2C(board.SCL, board.SDA)
        self.mlx = adafruit_mlx90640.MLX90640(self.i2c)
        self.mlx.refresh_rate = adafruit_mlx90640.RefreshRate.REFRESH_4_HZ  # Set to a feasible refresh rate

        self.frame = np.zeros((24 * 32,))

        pass

    def get_readings(self):
        # Return IR camera readings
        self.mlx.getFrame(self.frame)

        return self.frame
