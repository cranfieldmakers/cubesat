import smbus2
import time

BH1750_ADDRESS = 0x23
CONTINUOUS_HIGH_RES_MODE = 0x10

class LightSensor:
    def __init__(self, port):
        self.port = port
        # Initialize light sensor on the specified port

    def get_reading(self):
        # Return light sensor reading
        bus = smbus2.SMBus(self.port)
        data = bus.read_i2c_block_data(BH1750_ADDRESS, CONTINUOUS_HIGH_RES_MODE, 2)
        bus.close()
        return ((data[0] << 8) + data[1]) / 1.2


